class Candidato {
    constructor(numero, hora, minutos){
        this.numero = numero;
        this.hora = hora;
        this.minutos = minutos;
        
    }

    calcula(numero, array) {

        horas = this.hora;
        min = this.minutos;
        horaEmMinutos = horas/60+min;

    }



}